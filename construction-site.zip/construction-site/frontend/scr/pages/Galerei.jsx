const Galerei=()=>(
    <div>
        <h2>Галерея наших работ</h2>
        <p></p>
        <body>
            <img src="2.jpg" alt="2.jpg" />
            <img src="dizayn-interyera-4-komnantoj-kvartiry-144-kv-m-foto-14-3914.jpg" alt="dizayn-interyera-4-komnantoj-kvartiry-144-kv-m-foto-14-3914.jpg" />
            <img src="dushinurgaga-vannitoa-remont-1024x683.jpg" alt="dushinurgaga-vannitoa-remont-1024x683.jpg" />
            <img src="images (2).jpg" alt="images (2).jpg" />
        </body>
    </div>
)
import React from "react";
import '...styles/app.css';
export default Galerei