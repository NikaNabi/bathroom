import { Link } from 'react-router-dom';

    export default NavBa
export const NavBar = () => <nav>
    <Link to="/header">Главная<link />
        <link to="/calculation">Калькулятор</link>
        <link to="/about">О нас</link>
        <link to="/contacts">Контакты</link>
        <link to="/Usligi">Услуги</link>
        <link to="/Galerei">Галерея</link>
        <link to="/Blog">Блог</link>
    </Link>
    </nav>;

